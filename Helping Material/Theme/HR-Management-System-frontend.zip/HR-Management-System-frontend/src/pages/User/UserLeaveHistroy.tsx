import TableThree from '../../components/Tables/TableThree';

const UserLeaveHistroy = () => {
  return (
      <div className="p-8">
        <TableThree />
      </div>
  );
};

export default UserLeaveHistroy;
