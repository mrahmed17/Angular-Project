# CHANGELOG

## v2.0.0
- design change

## V 1.0.0
- Initial release