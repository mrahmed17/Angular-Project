import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormElementsRoutingModule } from './form-elements-routing.module';

@NgModule({
  declarations: [],
  imports: [CommonModule, FormElementsRoutingModule]
})
export class FormElementsModule {}
